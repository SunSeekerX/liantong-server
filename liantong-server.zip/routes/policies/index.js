/**
 * @name policies index.js
 * @author SunSeekerX
 * @time 2019-12-04 14:53:36
 * @LastEditors SunSeekerX
 * @LastEditTime 2019-12-18 18:20:44
 */

const Common = require('./CommonControllerPolicy.js')

module.exports = {
  Common
}
