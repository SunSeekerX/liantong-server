/**
 * @name 
 * @author SunSeekerX
 * @time 2019-12-04 14:53:36
 * @LastEditors SunSeekerX
 * @LastEditTime 2019-12-16 22:21:43
 */

const Common = require('./CommonControllerPolicy.js')

module.exports = {
  Common
}
