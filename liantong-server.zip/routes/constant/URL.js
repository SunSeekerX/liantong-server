/**
 * @name URL.js
 * @author SunSeekerX
 * @time 2019-12-10 18:03:47
 * @LastEditors SunSeekerX
 * @LastEditTime 2019-12-17 14:50:28
 */

module.exports = {
  Public: {
    HELLO_WORLD: '/',
    ADD: '/add',
    GET_CODE: '/get-code',
    FRIEND_HELP: '/friend-Help'
  },
  Private: {}
}
