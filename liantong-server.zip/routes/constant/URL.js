/**
 * @name URL.js
 * @author SunSeekerX
 * @time 2019-12-10 18:03:47
 * @LastEditors SunSeekerX
 * @LastEditTime 2019-12-18 20:48:06
 */

module.exports = {
  Public: {
    HELLO_WORLD: '/',
    ADD: '/add',
    GET_CODE: '/get-code',
    FRIEND_HELP: '/friend-help',
    DELETE_CODE: '/delete-code'
  },
  Private: {}
}
