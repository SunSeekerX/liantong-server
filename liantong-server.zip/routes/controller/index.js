/**
 * @name controller index.js
 * @author SunSeekerX
 * @time 2019-12-04 10:44:01
 * @LastEditors SunSeekerX
 * @LastEditTime 2019-12-18 18:19:38
 */

const Common = require('./CommonController.js')

module.exports = {
  Common
}
