/**
 * @name 
 * @author SunSeekerX
 * @time 2019-12-04 10:44:01
 * @LastEditors SunSeekerX
 * @LastEditTime 2019-12-16 22:21:29
 */

const Common = require('./CommonController.js')

module.exports = {
  Common,
}
