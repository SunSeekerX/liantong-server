/**
 * @name
 * @author SunSeekerX
 * @time 2019-12-02 18:11:24
 * @LastEditors SunSeekerX
 * @LastEditTime 2019-12-17 14:56:28
 */

const Common = require('./Common')

module.exports = {
  Common
}
