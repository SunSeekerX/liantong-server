/**
 * @name Request index.js
 * @author SunSeekerX
 * @time 2019-12-04 10:36:25
 * @LastEditors SunSeekerX
 * @LastEditTime 2019-12-18 20:31:26
 */

const createRequest = require('./Request')

module.exports = {
  request: createRequest(),
}
