/**
 * @name 
 * @author SunSeekerX
 * @time 2019-12-04 10:36:25
 * @LastEditors SunSeekerX
 * @LastEditTime 2019-12-17 14:53:50
 */

const createRequest = require('./Request')

module.exports = {
  request: createRequest(),
}
